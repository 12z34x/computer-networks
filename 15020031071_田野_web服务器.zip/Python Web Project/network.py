#-*- coding:utf-8 -*-
import BaseHTTPServer
import socket
import sys,os,BaseHTTPServer
import subprocess
import threading
from datetime import datetime

class HttpRequestHandler:
    bufsize=1024

    def __init__(self, clientsock, addr):
        self.clientsock = clientsock
        self.client_address = addr
        self.date_time_string = datetime.now()
        self.analyze()

    def analyze(self):

        # 接收数据，bufsize指明一次性读取的数据量
        data = self.clientsock.recv(self.bufsize)
        # print ' 收到---->%s\n%s' % (datetime.now(), data)

        # 浏览器有时候会连续发送两次请求，第二次data为空，原因待定
        if data.replace(" ", "") == "":
            print "data为空"
            return
        data = data.split('\r\n')
        # firstLine为 "GET /something.html?a=1&b=2 HTTP/1.1"
        firstLine = data[0]
        arr = firstLine.split(' ')
        self.command = arr[0]
        self.protocol = arr[2]
        if '?' in arr[1]:
            # 如果带参数的话存入paramStr="a=1&b=2"
            # path存放相对路径
            self.path, self.paramStr = arr[1].split('?')
        else:
            self.path = arr[1]
            self.paramStr = ""


        # 把请求头部的剩余的信息按照键值对的方式放入headers字典中
        # Accept-Language:zh - cn
        # Connection:Keep - Alive
        # Host:localhost
        # Accept-Encoding:gzip, deflate
        self.headers = {}
        for line in data[1:]:
            if ':' in line:
                key, value = line.split(':', 1)
                self.headers[key] = value

        # 调用方法进行处理，这个函数已经在第一版中实现。
        self.do_GET()
        #time.sleep(30)

    http_response = "HTTP/1.1"

    def send_response(self, status):
        if status == 200:
            self.http_response += "200" + " " + "OK"
        elif status == 404:
            self.http_response += "400" + " " + "Not Found"
        self.http_response += '\r\n'

    # "Content-Type", "text/html"
    # "Content-Length", length
    def send_header(self, key, value):
        self.http_response += str(key) + ": " + str(value) + '\r\n'

    def end_headers(self):
        self.http_response += '\r\n'

    def write(self, page):
        self.http_response += str(page)
        self.clientsock.send(self.http_response)
        self.clientsock.close()
class RequestHandler(HttpRequestHandler):
    '''处理请求并返回页面'''

    # 页面模板
    Page = '''\
    <html>
    <body>
    <table border=1s>
    <tr>  <td>Header</td>         <td>Value</td>          </tr>
    <tr>  <td>Date and time</td>  <td>{date_time}</td>    </tr>
    <tr>  <td>Client host</td>    <td>{client_host}</td>  </tr>
    <tr>  <td>Client port</td>    <td>{client_port}</td> </tr>
    <tr>  <td>Command</td>        <td>{command}</td>      </tr>
    <tr>  <td>Path</td>           <td>{path}</td>         </tr>
    </table>
    </body>
    </html>
    '''
    Error_Page = """\
        <html>
        <body>
        <h1>Error accessing {path}</h1>
        <p>{msg}</p>
        </body>
        </html>
        """


    def handleError(self, msg):
        content = self.Error_Page.format(path=self.path, msg=msg)
        self.send_content(content, 404)

    def handleFile(self, fullPath):
        # 处理python脚本
        if fullPath.endswith('.py'):
            # data为脚本运行后的返回值
            data = subprocess.check_output(['python', fullPath,self.paramStr])
            self.send_content(data)
            return
        try:
            with open(fullPath, 'rb') as reader:
                content = reader.read()
            self.send_content(content)
        except IOError as msg:
            msg = "'{0}' cannot be read:{1}".format(self.path, msg)
            self.handleError(msg)

    def do_GET(self):
        try:
            fullPath = os.getcwd() + self.path
            if not os.path.exists(fullPath):
                raise ServerException("'{0}' not found".format(self.path))
            elif os.path.isfile(fullPath):
                self.handleFile(fullPath)
            # 访问根路径
            elif os.path.isdir(fullPath):
                # fullPath = os.path.join(fullPath, "index.html")
                fullPath = fullPath + "index.html"
                if os.path.isfile(fullPath):
                    self.handleFile(fullPath)
                else:
                    raise ServerException("'{0}' not found".format(self.path))
            else:
                raise ServerException("Unknown object '{0}'".format(self.path))
        except Exception as msg:
            self.handleError(msg)


    def create_page(self):
        values = {
            'date_time': self.date_time_string(),
            'client_host': self.client_address[0],
            'client_port': self.client_address[1],
            'command': self.command,
            'path': self.path
        }
        page = self.Page.format(**values)
        return page


    def send_content(self, content, status=200):
        self.send_response(status)
        self.send_header("Content-type", "text/html")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.write(content)
class HttpServer:

    def __init__(self, serverAddr, RequestHandler):
        self.serverAddr = serverAddr
        self.requestHandler = RequestHandler

    def serve_forever(self):
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.bind(serverAddr)
        server_sock.listen(10)

        while True:
            print 'waiting for connection...'
            clientsock,addr = server_sock.accept()
            print 'received from :', addr
            thread = threading.Thread(target=self.startThread, args=(clientsock, addr,))
            thread.setDaemon(True)
            thread.start()
        server_sock.close()

    def startThread(self, clientsock, addr):
        handler = RequestHandler(clientsock, addr)
class ServerException(Exception):
    '''服务器内部错误'''
    pass


#----------------------------------------------------------------------

if __name__ == '__main__':
    serverAddr = ('localhost',5555)
    server = HttpServer(serverAddr, RequestHandler)
    server.serve_forever()