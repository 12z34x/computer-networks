import sys
paramStr = sys.argv[1]
paramArr = paramStr.split('&')
paramDict = {}
for param in paramArr:
    key, value = param.split('=')
    paramDict[key] = value

print ('''\
<html>
<body>
<p>a + b = {0}</p>
</body>
</html>'''.format((int(paramDict['a']) + int(paramDict['b']))))